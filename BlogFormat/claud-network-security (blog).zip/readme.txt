Hi, Team
One file upload here 
1. assests_blogs\img
   23.jpg
2. upload one blog-
   Cloud-Network-Security-Solutions-Protect-Your-Cloud-Environment.html
3. Replace file 
   Blog-Domgys.html
