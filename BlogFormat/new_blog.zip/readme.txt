Hi, Team
One file upload here 
1. assests_blogs\img
   22.jpg
2. upload one blog-
   GeoTrust-SSL-Certificate-Features-Advantages-and-Benefits.html
3. Replace file 
   Blog-Domgys.html
